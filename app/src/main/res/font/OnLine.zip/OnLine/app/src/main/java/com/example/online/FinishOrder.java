package com.example.online;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FinishOrder extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finish_order);
    }
}